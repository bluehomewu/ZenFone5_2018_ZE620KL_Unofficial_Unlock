<!-- Copyright 2015 The Chromium Authors. All rights reserved.
     Use of this source code is governed by a BSD-style license that can be
     found in the LICENSE file.
-->
Systrace
========

Systrace provides command-line tools to analyze the performance of your
application. It currently includes
[Android Systrace](http://developer.android.com/tools/help/systrace.html).
